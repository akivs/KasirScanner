package club.akivs.kasirscanner;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ProgressBar;
import android.widget.TextView;

import club.akivs.kasirscanner.home.HomeActivity;

public class SplashActivity extends AppCompatActivity {

    private TextView tvSplash;
    private TextView versi;
    private String version;

    ProgressBar bar;

    private Handler progressBarHandler = new Handler();

    GradientDrawable progressGradientDrawable = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, new int[]{
            0xff1e90ff,0xff006ab6,0xff367ba8});
    ClipDrawable progressClipDrawable = new ClipDrawable(
            progressGradientDrawable, Gravity.LEFT, ClipDrawable.HORIZONTAL);
    Drawable[] progressDrawables = {
            new ColorDrawable(0xffffffff),
            progressClipDrawable, progressClipDrawable};
    LayerDrawable progressLayerDrawable = new LayerDrawable(progressDrawables);


    int status = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        tvSplash = (TextView) findViewById(R.id.tvSplash);
        versi = (TextView) findViewById(R.id.versi);


        bar = (ProgressBar) findViewById(R.id.progresBar1);
        bar.setProgress(0);
        bar.setMax(100);

        progressLayerDrawable.setId(0, android.R.id.background);
        progressLayerDrawable.setId(1, android.R.id.secondaryProgress);
        progressLayerDrawable.setId(2, android.R.id.progress);

        bar.setProgressDrawable(progressLayerDrawable);
        //=======================
        PackageInfo pInfo = null;
        try {
            pInfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        version = pInfo.versionName;
        versi.setText("v."+version);


        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(getApplicationContext(), MenuActivity.class));
                finish();
            }
        }, 3000L); //3000 L = 3 detik



    }
}
